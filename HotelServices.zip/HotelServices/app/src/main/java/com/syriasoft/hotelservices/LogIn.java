package com.syriasoft.hotelservices;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.syriasoft.hotelservices.lodingDialog;
import java.util.HashMap;
import java.util.Map;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class LogIn extends AppCompatActivity {
    /**

     */
    static roomDataBase room ;
    private int roomNumber , floor ;
    private String password ;
    private Button go ;
    private EditText roomEntry , floorEntry , passwordEntry ;
    private String url="https://bait-elmoneh.online/hotel-service/insertRoom.php";
    Activity act = this ;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        room = new roomDataBase(this);
        roomEntry = (EditText) findViewById(R.id.roomNymberEntry);
        floorEntry = (EditText) findViewById(R.id.floorNumberEntry);
        passwordEntry = (EditText) findViewById(R.id.passwordEntry);
        if (room.isLogedIn())
        {
            Intent i = new Intent(act , FullscreenActivity.class);
            startActivity(i);
        }

    }


    public void goRegist(View view)
    {

        if (roomEntry.getText().toString().length() > 0)
        {
            roomNumber =Integer.parseInt( roomEntry.getText().toString() );
            if (floorEntry.getText().toString().length() > 0 )
            {
                floor = Integer.parseInt(floorEntry.getText().toString());

                if (passwordEntry.getText().toString().length() > 0)
                {
                    password = passwordEntry.getText().toString();
                    final lodingDialog dialog = new lodingDialog(act);

                    StringRequest request = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response)
                        {
                            dialog.stop();
                            if (response.equals("1"))
                            {
                                Toast.makeText(act,"تم تسجيل الغرفة",Toast.LENGTH_LONG).show();
                                Intent i = new Intent(act , FullscreenActivity.class);
                                room.insertRoom(roomNumber,"Room",floor,"0");
                                startActivity(i);
                            }
                            else
                                {
                                    Toast.makeText(act,"كلمة المرور خطأ",Toast.LENGTH_LONG).show();
                                }

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error)
                        {
                            dialog.stop();
                            Toast.makeText(act,error.getMessage(),Toast.LENGTH_LONG).show();

                        }
                    })
                    {
                        @Override
                        protected Map<String, String> getParams() throws AuthFailureError {
                            Map<String,String> params = new HashMap<String,String>();
                            params.put("roomNumber",String.valueOf(roomNumber));
                            params.put("floor",String.valueOf(floor));
                            params.put("password",password);
                            return params;
                        }
                    };
                    Volley.newRequestQueue(act).add(request);
                }
                else
                    {
                        Toast.makeText(this , "يجب ادخال كلمة المرور",Toast.LENGTH_LONG).show();
                    }

            }
            else
                {
                    Toast.makeText(this , "يجب ادخال رقم الطابق",Toast.LENGTH_LONG).show();

                }
        }
        else
            {
                Toast.makeText(this , "يجب ادخال رقم الغرفة",Toast.LENGTH_LONG).show();
            }
    }
}
