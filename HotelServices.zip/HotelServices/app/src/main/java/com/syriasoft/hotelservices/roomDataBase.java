package com.syriasoft.hotelservices;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class roomDataBase extends SQLiteOpenHelper {

    private static  int DATABASE_VESION = 1 ;
    private static String DATABASE_NAME = "Room" ;
    SQLiteDatabase db ;

    public roomDataBase( Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VESION);
        db =getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL("CREATE TABLE IF NOT EXISTS room ( 'id' INTEGER PRIMARY KEY ,'RoomNumber' INTEGER , 'RoomType' VARCHAR , 'Floor' INTEGER,'token' TEXT ) ");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("DROP TABLE IF EXISTS 'room'");
        onCreate(db);
    }
    public boolean insertRoom (int RoomNumber ,String RoomType, int Floor , String token  )
    {
        boolean result = false ;
        ContentValues values = new ContentValues();
        values.put("RoomNumber",RoomNumber);
        values.put("RoomType",RoomType);
        values.put("Floor",Floor);
        values.put("token",token);
        try {
            db.insert("room", null, values);
            result = true ;
        }catch (Exception e )
        {
            result = false ;
        }

        return result ;
    }
    public boolean isLogedIn()
    {
        boolean result = false ;
        Cursor c = db.query("room", new String[]{"id"}, "", null, null, null, null);
        if (c.getCount() == 1)
        {
            result = true ;
        }
        else
        {
            result = false ;
        }

        return result;
    }
    public int getRoomNumber()
    {
        int num = 0 ;
        Cursor c = db.query("room", new String[]{"RoomNumber"}, "", null, null, null, null);
        c.moveToFirst();
        num = c.getInt(0);

        return num ;
    }
}
