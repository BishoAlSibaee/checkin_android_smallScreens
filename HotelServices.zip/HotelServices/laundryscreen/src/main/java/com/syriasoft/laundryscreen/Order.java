package com.syriasoft.laundryscreen;

public class Order
{
    String caption ;
    String roomNumber ;

    Order(String roomNumber , String caption)
    {
        this.roomNumber = roomNumber ;
        this.caption = caption ;
    }
}
