package com.syriasoft.laundryscreen;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class messagingService extends FirebaseMessagingService {
    public messagingService() {
    }


    @Override
    public void onMessageReceived(RemoteMessage remoteMessage)
    {
        MainActivity.list[3] = new Order("4" , "from");
        OrdersAdapter a = new OrdersAdapter(getApplicationContext(),MainActivity.list);
        MainActivity.gridView.setAdapter(a);
    }

}
